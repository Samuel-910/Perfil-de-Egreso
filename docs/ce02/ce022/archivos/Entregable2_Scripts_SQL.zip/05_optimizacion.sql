-- =============================================================================
-- 05_optimizacion.sql · Rendimiento de la consulta más frecuente del kardex
-- KardexRepository.findLastMovement se ejecuta en CADA movimiento (venta,
-- compra, ajuste) para calcular el saldo:
--   SELECT * FROM kardex WHERE id_catalogo = ? AND id_sucursal = ?
--   ORDER BY fecha DESC, id_articulo_kardex DESC LIMIT 1
-- Hoy solo existen índices de una columna (id_catalogo, id_sucursal, fecha).
-- Base: clinica_db_e2 con 300 000 movimientos sintéticos.
-- =============================================================================
\echo '=== Generando 300 000 movimientos de kardex (10 productos x 2 sedes, 2 años) ==='
INSERT INTO kardex (id_articulo_kardex, id_alm_articulo, id_catalogo, id_sucursal, id_usuario, id_documento, num_doc,
                    fecha, operacion, detalle, observacion, signo, cantidad, costo_unitario, costo_total,
                    saldo_cantidad, saldo_costo_unitario, saldo_costo_total, origen_id, origen_tipo, presentacion)
SELECT 'K-' || g, 1, c.id, 1 + (g % 2), (SELECT min(id) FROM datos_personales), '03', 'B001-' || g,
       timestamp '2025-01-01' + (g % 700) * interval '1 day' + (g % 86400) * interval '1 second',
       CASE WHEN g % 5 = 0 THEN 'COMPRA' ELSE 'VENTA' END, 'Carga de prueba', '-', CASE WHEN g % 5 = 0 THEN '+' ELSE '-' END,
       1 + g % 7, 2.50, 2.50 * (1 + g % 7), 500, 2.50, 1250, g::text, 'VTA', 'UND'
  FROM generate_series(1, 300000) g
  JOIN LATERAL (SELECT id FROM catalogo ORDER BY id OFFSET (g % 10) LIMIT 1) c ON true;
ANALYZE kardex;
SELECT count(*) AS movimientos FROM kardex;

\echo '=== ANTES: plan con los índices actuales (una columna) ==='
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT * FROM kardex WHERE id_catalogo = 3 AND id_sucursal = 1
 ORDER BY fecha DESC, id_articulo_kardex DESC LIMIT 1;

\echo '=== Índice compuesto propuesto (coincide con WHERE + ORDER BY) ==='
CREATE INDEX IF NOT EXISTS idx_kardex_ultimo_mov
    ON kardex (id_catalogo, id_sucursal, fecha DESC, id_articulo_kardex DESC);
ANALYZE kardex;

\echo '=== DESPUÉS: plan con idx_kardex_ultimo_mov ==='
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT * FROM kardex WHERE id_catalogo = 3 AND id_sucursal = 1
 ORDER BY fecha DESC, id_articulo_kardex DESC LIMIT 1;
