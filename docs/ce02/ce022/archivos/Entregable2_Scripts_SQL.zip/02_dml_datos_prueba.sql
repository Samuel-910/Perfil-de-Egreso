-- =============================================================================
-- 02_dml_datos_prueba.sql  ·  Salud Total SAC · ERP «Articulos»
-- DML de prueba sobre el ESQUEMA REAL (generado por Hibernate).
-- Base de trabajo: clinica_db_e2 (copia de clinica_db). No se ejecuta en la base
-- de desarrollo. Los datos semilla reales los cargan los inicializadores Java
-- (DataInitializer, CoreBusinessInitializer) desde src/main/resources/data/seed.
-- =============================================================================
BEGIN;

-- 1. Sedes de Salud Total (la semilla real trae «Sede Principal, Lima»)
UPDATE sucursal
   SET nombre = 'Sede Central Juliaca', direccion = 'Jr. San Román 345, Juliaca',
       fecha_actualizacion = now()
 WHERE id_sucursal = 1;

INSERT INTO sucursal (id_sucursal, nombre, direccion, telefono, estado, fecha_creacion, fecha_actualizacion, created_by, updated_by)
OVERRIDING SYSTEM VALUE
VALUES (2, 'Sucursal Puno', 'Jr. Lima 512, Puno', '051-365200', 1, now(), now(), 'dml_e2', 'dml_e2')
ON CONFLICT DO NOTHING;
SELECT setval(pg_get_serial_sequence('sucursal','id_sucursal'), (SELECT max(id_sucursal) FROM sucursal));

INSERT INTO almacen (nombre, codigo, es_principal, estado, actualiza_precio, canje_stock_fijo, fecha_crea, fecha_fin,
                     id_user_crea, maneja_petitorio, ped_interdep, receta, tipo, id_sucursal, created_at, usuario_creacion)
SELECT 'ALMACÉN PRINCIPAL - Sucursal Puno', 'ALM-PUN', true, 1, actualiza_precio, canje_stock_fijo, current_date, fecha_fin,
       id_user_crea, maneja_petitorio, ped_interdep, receta, tipo, 2, now(), 'dml_e2'
  FROM almacen WHERE id = 1
   AND NOT EXISTS (SELECT 1 FROM almacen WHERE codigo = 'ALM-PUN');

-- 2. Lotes, vencimientos y punto de reorden en los productos semilla (Juliaca)
UPDATE productos SET nro_lote = 'L-2291', fecha_venc = DATE '2027-01-12', stock_minimo = 100, stock_maximo = 600, dias_alerta_vencimiento = 90 WHERE id_producto = 1;
UPDATE productos SET nro_lote = 'L-1180', fecha_venc = current_date + 25,  stock_minimo = 60,  stock_maximo = 300, dias_alerta_vencimiento = 90 WHERE id_producto = 2;
UPDATE productos SET nro_lote = 'L-0444', fecha_venc = DATE '2027-08-30', stock_minimo = 80,  stock_maximo = 500, dias_alerta_vencimiento = 90 WHERE id_producto = 3;
UPDATE productos SET nro_lote = 'L-3310', fecha_venc = current_date + 70,  stock_minimo = 40,  stock_maximo = 250, dias_alerta_vencimiento = 90 WHERE id_producto = 4;
UPDATE productos SET nro_lote = 'L-7713', fecha_venc = current_date + 15,  stock_minimo = 30,  stock_maximo = 200, dias_alerta_vencimiento = 60 WHERE id_producto = 5;
UPDATE productos SET nro_lote = 'L-0932', fecha_venc = DATE '2027-02-28', stock_minimo = 50,  stock_maximo = 400, dias_alerta_vencimiento = 90 WHERE id_producto = 6;

-- 3. Segundo lote de Paracetamol (vence antes → debe salir primero por FEFO) y lotes en Puno
INSERT INTO productos (id_catalogo, id_sucursal, id_almacen, nro_lote, fecha_venc, stock, stock_minimo, stock_maximo,
                       precio_compra, precio_venta_unitario, dias_alerta_vencimiento, presentacion, fecha_reg, usuario_crea)
SELECT id_catalogo, 1, 1, 'L-2105', current_date + 40, 80, 100, 600, precio_compra, precio_venta_unitario, 90, presentacion, now(), 'dml_e2'
  FROM productos WHERE id_producto = 1;

INSERT INTO productos (id_catalogo, id_sucursal, id_almacen, nro_lote, fecha_venc, stock, stock_minimo, stock_maximo,
                       precio_compra, precio_venta_unitario, dias_alerta_vencimiento, presentacion, fecha_reg, usuario_crea)
SELECT p.id_catalogo, 2, (SELECT id FROM almacen WHERE codigo = 'ALM-PUN'), v.lote, v.venc, v.stock, v.minimo, v.maximo,
       p.precio_compra, p.precio_venta_unitario, 90, p.presentacion, now(), 'dml_e2'
  FROM productos p
  JOIN (VALUES (1, 'L-2290', DATE '2027-01-12', 140::numeric, 60::numeric, 300::numeric),
               (2, 'L-1181', current_date + 20,    18::numeric, 60::numeric, 120::numeric),
               (5, 'L-7714', current_date - 5,      12::numeric, 30::numeric, 150::numeric)) v(id, lote, venc, stock, minimo, maximo)
    ON v.id = p.id_producto;

COMMIT;

\echo '=== Lotes cargados por sede (FEFO: ordenados por vencimiento) ==='
SELECT s.nombre AS sede, c.nombre_catalogo AS producto, p.nro_lote, p.fecha_venc, p.stock, p.stock_minimo
  FROM productos p JOIN catalogo c ON c.id = p.id_catalogo JOIN sucursal s ON s.id_sucursal = p.id_sucursal
 WHERE p.nro_lote IS NOT NULL
 ORDER BY s.id_sucursal, c.nombre_catalogo, p.fecha_venc;
