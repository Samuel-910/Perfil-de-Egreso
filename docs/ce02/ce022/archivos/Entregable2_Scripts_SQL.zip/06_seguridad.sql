-- =============================================================================
-- 06_seguridad.sql · Roles de base de datos con mínimo privilegio (PROPUESTA)
-- Situación real: el backend se conecta como «postgres» (superusuario) en el
-- perfil local. Este script define roles para producción. En la demostración
-- se crean como NOLOGIN y se prueban con SET ROLE; en producción se activan con
--   ALTER ROLE st_app LOGIN PASSWORD :'clave_desde_gestor_de_secretos';
-- =============================================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'st_app')      THEN CREATE ROLE st_app NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'st_reportes') THEN CREATE ROLE st_reportes NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'st_dba')      THEN CREATE ROLE st_dba NOLOGIN; END IF;
END $$;

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO st_app, st_reportes, st_dba;

-- st_dba: administración del esquema (migraciones Flyway)
GRANT ALL PRIVILEGES ON ALL TABLES    IN SCHEMA public TO st_dba;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO st_dba;
GRANT CREATE ON SCHEMA public TO st_dba;

-- st_app: lo que necesita el backend en ejecución (DML, sin DDL ni DELETE físico: soft-delete)
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO st_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO st_app;
-- Las bitácoras solo admiten inserción (no se pueden alterar)
REVOKE UPDATE ON lab_auditoria, intruso, datos_clinica_auditoria, puntos_documento_auditoria FROM st_app;
-- Excepciones donde el código sí borra físicamente (tablas puente de seguridad y sesiones)
GRANT DELETE ON user_roles, role_permissions, user_permissions, sessiones TO st_app;

-- st_reportes: solo lectura, sin datos clínicos ni de credenciales
GRANT SELECT ON ALL TABLES IN SCHEMA public TO st_reportes;
REVOKE SELECT ON datos_personales, datos_clinica, datos_medico, sessiones, intruso FROM st_reportes;

\echo '=== Privilegios efectivos por rol (resumen) ==='
SELECT grantee, privilege_type, count(*) AS tablas
  FROM information_schema.role_table_grants
 WHERE grantee IN ('st_app', 'st_reportes', 'st_dba')
 GROUP BY grantee, privilege_type ORDER BY grantee, privilege_type;

\echo '=== Prueba 1: st_app intenta borrar físicamente una venta ==='
\set ON_ERROR_STOP 0
SET ROLE st_app;
DELETE FROM venta_registro WHERE id_venta = 1;
\echo '=== Prueba 2: st_app intenta alterar la bitácora de auditoría ==='
UPDATE lab_auditoria SET status = 'X' WHERE id = 1;
\echo '=== Prueba 3: st_app sí puede registrar (soft-delete = UPDATE de estado) ==='
BEGIN; UPDATE venta_registro SET estado = 3 WHERE id_venta = 1; ROLLBACK;
RESET ROLE;
\echo '=== Prueba 4: st_reportes intenta leer credenciales de usuarios ==='
SET ROLE st_reportes;
SELECT login FROM datos_personales LIMIT 1;
\echo '=== Prueba 5: st_reportes sí lee ventas ==='
SELECT count(*) AS ventas FROM venta_registro;
RESET ROLE;
\set ON_ERROR_STOP 1
