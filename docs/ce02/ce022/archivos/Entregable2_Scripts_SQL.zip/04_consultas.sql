-- =============================================================================
-- 04_consultas.sql · Consultas que ejecuta REALMENTE la aplicación
-- (copiadas de los repositorios Spring Data; los :parámetros se sustituyen
--  por valores de prueba). Base: clinica_db_e2.
-- =============================================================================
\echo '=== C1. ProductoRepository.findProductosEnAlertaVencimientoPorSucursal (AlertaSchedulerService, diario) ==='
SELECT p.id_producto, p.nro_lote, p.fecha_venc, p.fecha_venc - current_date AS dias_restantes,
       COALESCE(p.dias_alerta_vencimiento, 90) AS umbral
  FROM productos p
 WHERE p.id_sucursal = 1 AND p.fecha_venc IS NOT NULL
   AND p.fecha_venc >= CAST(current_date AS date)
   AND p.fecha_venc <= (CAST(current_date AS date) + COALESCE(p.dias_alerta_vencimiento, 90))
 ORDER BY p.fecha_venc;

\echo '=== C2. ProductoRepository.findStockCriticoPorSucursal (JPQL: p.stock <= p.stockMinimo AND p.stockMinimo > 0) ==='
SELECT p.id_producto, c.nombre_catalogo, p.nro_lote, p.stock, p.stock_minimo
  FROM productos p JOIN catalogo c ON c.id = p.id_catalogo
 WHERE p.id_sucursal = 2 AND p.stock <= p.stock_minimo AND p.stock_minimo > 0;

\echo '=== C3. Búsqueda para venta (JPQL con LOWER/CONCAT, soloVenta = true: excluye vencidos) ==='
SELECT p.id_producto, c.nombre, p.nro_lote, p.fecha_venc, p.precio_venta_unitario
  FROM productos p JOIN catalogo c ON c.id = p.id_catalogo
 WHERE p.id_sucursal = 2
   AND (p.precio_venta_unitario IS NOT NULL AND p.precio_venta_unitario > 0
        AND (p.fecha_venc IS NULL OR p.fecha_venc >= current_date))
   AND LOWER(c.nombre) LIKE LOWER(CONCAT('%', 'amox', '%'));
-- Con 'ceti' devuelve 0 filas: el único lote de Cetirizina en Puno (L-7714) está vencido.

\echo '=== C4. Ventas por día (base del dashboard «Resumen ventas mensuales») ==='
SELECT fecha, COUNT(*) AS comprobantes, SUM(total)::NUMERIC(12,2) AS importe
  FROM venta_registro
 WHERE estado <> 3
 GROUP BY fecha ORDER BY fecha DESC LIMIT 5;

\echo '=== C5. Productos más vendidos (venta_detalle.id_articulo -> productos -> catalogo) ==='
-- Nota: en los datos reales venta_detalle.id_catalogo está vacío; el vínculo efectivo es id_articulo (lote).
SELECT c.nombre_catalogo, SUM(d.cantidad)::NUMERIC(12,2) AS unidades, SUM(d.total)::NUMERIC(12,2) AS importe
  FROM venta_detalle d
  JOIN venta_registro v ON v.id_venta = d.id_venta AND v.estado <> 3
  JOIN productos p ON p.id_producto = d.id_articulo
  JOIN catalogo c ON c.id = p.id_catalogo
 GROUP BY c.nombre_catalogo ORDER BY unidades DESC LIMIT 5;

\echo '=== C6. Outbox: eventos pendientes que procesa PostgresEventListenerService ==='
SELECT id, topico, estado, fecha_creacion FROM cola_eventos WHERE estado = 'PENDIENTE' ORDER BY fecha_creacion ASC;
