-- =============================================================================
-- 07_monitoreo.sql · Consultas de monitoreo y administración (PostgreSQL 17)
-- =============================================================================
\echo '=== M1. Inventario de objetos del esquema ==='
SELECT (SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE') AS tablas,
       (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid=c.connamespace WHERE n.nspname='public' AND contype='f') AS llaves_foraneas,
       (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid=c.connamespace WHERE n.nspname='public' AND contype='c') AS checks,
       (SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid=c.connamespace WHERE n.nspname='public' AND contype='u') AS uniques,
       (SELECT count(*) FROM pg_indexes WHERE schemaname='public') AS indices,
       (SELECT count(*) FROM information_schema.triggers WHERE trigger_schema='public') AS triggers,
       pg_size_pretty(pg_database_size(current_database())) AS tamano_bd;

\echo '=== M2. Tablas más grandes ==='
SELECT relname AS tabla, pg_size_pretty(pg_total_relation_size(relid)) AS tamano_total, n_live_tup AS filas_vivas, n_dead_tup AS filas_muertas
  FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 6;

\echo '=== M3. Uso de índices de kardex ==='
SELECT indexrelname AS indice, idx_scan AS veces_usado, pg_size_pretty(pg_relation_size(indexrelid)) AS tamano
  FROM pg_stat_user_indexes WHERE relname = 'kardex' ORDER BY idx_scan DESC;

\echo '=== M4. Índices nunca usados (candidatos a revisión) ==='
SELECT relname AS tabla, count(*) AS indices_sin_uso
  FROM pg_stat_user_indexes WHERE idx_scan = 0 GROUP BY relname ORDER BY 2 DESC LIMIT 5;

\echo '=== M5. Proporción de aciertos en caché ==='
SELECT round(100.0 * sum(blks_hit) / NULLIF(sum(blks_hit) + sum(blks_read), 0), 2) AS cache_hit_pct
  FROM pg_stat_database WHERE datname = current_database();

\echo '=== M6. Conexiones activas por usuario ==='
SELECT usename, state, count(*) FROM pg_stat_activity WHERE datname = current_database() GROUP BY 1, 2;

\echo '=== M7. Salud del Outbox (eventos por estado) ==='
SELECT estado, count(*) FROM cola_eventos GROUP BY estado;

\echo '=== M8. Intentos de acceso fallidos registrados por la app (tabla intruso) ==='
SELECT failure_reason, count(*) FROM intruso GROUP BY failure_reason;
