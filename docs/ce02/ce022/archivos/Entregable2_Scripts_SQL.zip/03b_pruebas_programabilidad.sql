-- Pruebas de los objetos de 03_programabilidad.sql (base clinica_db_e2)
\pset footer on
\echo '=== P1. Outbox real: LISTEN + INSERT en cola_eventos -> pg_notify ==='
LISTEN nuevo_evento_outbox;
INSERT INTO cola_eventos (modulo, topico, titulo, contenido, tipo, estado, fecha_creacion)
VALUES ('VENTAS', 'sistema.notificaciones', 'Prueba de notificación', '{"userId":"","titulo":"Prueba"}', 'INFO', 'PENDIENTE', now());
SELECT 1 AS espera_notificacion;

\echo '=== P2. fn_lote_fefo: Paracetamol en Juliaca (debe salir primero L-2105) ==='
SELECT * FROM fn_lote_fefo((SELECT id_catalogo FROM productos WHERE id_producto = 1), 1);

\echo '=== P3. fn_lote_fefo: Cetirizina en Puno (lote L-7714 vencido -> no se ofrece) ==='
SELECT * FROM fn_lote_fefo((SELECT id_catalogo FROM productos WHERE id_producto = 5), 2);

\echo '=== P4. sp_generar_ordenes_reabastecimiento (Puno) ==='
CALL sp_generar_ordenes_reabastecimiento(2);
SELECT o.id, c.nombre_catalogo, o.stock_al_generar, o.stock_minimo, o.cantidad_sugerida, o.estado
  FROM orden_reabastecimiento o JOIN catalogo c ON c.id = o.id_catalogo ORDER BY o.id;

\echo '=== P5. Segunda ejecución: no duplica órdenes abiertas (índice único parcial) ==='
CALL sp_generar_ordenes_reabastecimiento(2);

\echo '=== P6. Eventos generados en el Outbox real ==='
SELECT id, topico, titulo, estado FROM cola_eventos ORDER BY id;

\echo '=== P7. Trigger de auditoría: cambio de precio y stock fuera de la app ==='
UPDATE productos SET precio_venta_unitario = 8.50, stock = stock - 10 WHERE id_producto = 1;
SELECT id, action, module, details, method, username FROM lab_auditoria WHERE method = 'DB-TRIGGER' ORDER BY id;

\echo '=== P8. CHECK stock >= 0: un stock negativo se rechaza ==='
\set ON_ERROR_STOP 0
UPDATE productos SET stock = -5 WHERE id_producto = 3;
\set ON_ERROR_STOP 1

\echo '=== P9. fn_stock_valorizado(1) ==='
SELECT * FROM fn_stock_valorizado(1);
