# =============================================================================
# 08_respaldo_restauracion.ps1 · Respaldo lógico y prueba de restauración
# Uso: $env:PGPASSWORD = '<desde el gestor de secretos>'; .\08_respaldo_restauracion.ps1
# En producción (AWS, CE03): snapshots automáticos de RDS + PITR (retención 7 días)
# y copia diaria de este dump a S3 con cifrado SSE.
# =============================================================================
$PG    = "C:\Program Files\PostgreSQL\17\bin"
$DB    = "clinica_db_e2"
$FECHA = Get-Date -Format "yyyyMMdd_HHmm"
$DUMP  = "respaldo_${DB}_$FECHA.dump"

# 1. Respaldo completo en formato custom (comprimido, restauración selectiva)
& "$PG\pg_dump.exe" -h localhost -U postgres -d $DB -F c -Z 6 -f $DUMP
Get-Item $DUMP | Select-Object Name, Length

# 2. Restauración en una base nueva (simulacro de recuperación)
& "$PG\createdb.exe"   -h localhost -U postgres "${DB}_restore"
& "$PG\pg_restore.exe" -h localhost -U postgres -d "${DB}_restore" --no-owner $DUMP

# 3. Verificación: conteos origen vs. restaurada
$q = "SELECT 'productos' t, count(*) FROM productos UNION ALL SELECT 'kardex', count(*) FROM kardex " +
     "UNION ALL SELECT 'venta_registro', count(*) FROM venta_registro UNION ALL SELECT 'venta_detalle', count(*) FROM venta_detalle " +
     "UNION ALL SELECT 'orden_reabastecimiento', count(*) FROM orden_reabastecimiento ORDER BY 1"
& "$PG\psql.exe" -h localhost -U postgres -d $DB            -X -A -t -c $q
& "$PG\psql.exe" -h localhost -U postgres -d "${DB}_restore" -X -A -t -c $q

# 4. Limpieza del simulacro
& "$PG\dropdb.exe" -h localhost -U postgres "${DB}_restore"
